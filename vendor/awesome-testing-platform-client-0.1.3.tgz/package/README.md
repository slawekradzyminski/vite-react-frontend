# Awesome Testing Platform Client

Framework-neutral browser contracts shared by the Awesome Testing storefront and AI Learning Lab.

It owns token storage compatibility, authenticated Axios behavior, refresh coordination, client-session headers, and safe same-origin login return URLs. React guards, routes, and UI remain inside each application.

## Scope

- Preserves the existing `localStorage` keys: `token`, `refreshToken`, and `clientSessionId`.
- Adds bearer tokens and client-session IDs to protected Axios requests.
- Coordinates one refresh request across concurrent `401` responses and retries each request once.
- Clears an invalid session and redirects to `/login?returnTo=...` with a same-origin-safe return path.
- Exposes navigation helpers that work across separately deployed frontends.

This package intentionally does not own React components, route configuration, visual design, API domain types, or server authentication. It also does not migrate the platform to cookie-based sessions.

## Development

```bash
npm ci
npm test
npm run build
npm pack
```

The current local consumers install the packed artifact from their `vendor/` directories, which keeps Docker builds deterministic while this package lives in a separate repository.
